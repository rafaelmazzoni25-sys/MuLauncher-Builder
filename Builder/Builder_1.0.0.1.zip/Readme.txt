MU Launcher Builder version 1.0.0 build 1

* Can create launchers for MU Online.
* Varius features to use like skinning, autoupdate client files, etc.

This software is freeware but it is copyrighted.
Copyright 2004-2005 BlurCode - SkyTeam

http://sky.xn.pl/


Changes:

1.0.0.0 (pre-release)
* Initial release.

1.0.0.1
+ Fixed browser not opening correct page due to xml value request bug.